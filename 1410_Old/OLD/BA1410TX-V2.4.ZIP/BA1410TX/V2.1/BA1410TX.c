#include <BA1410TX.h>
//#include <stdlib.h>
#include <ctype.h>
#include "PIC18F45K22_registers.h"

#define VERSION "\r\nBA1410TX V2.1\r\n"

//--------- frequency constants --------------------------------
#define FREQ_P_MULT           32L
#define FREQ_BASE        2185000L       // in KHz
#define FREQ_TOP         2400000L       // in KHz
#define FREQ_STEP            100L       // in KHz
#define FREQ_OSC           10000L       // in KHz
#define FREQ_MOD              ((FREQ_OSC / FREQ_STEP) / RFdiv)

//========== power =============================================
UINT power_level, power_control;
UINT manual_power = 0xFFFF;

//========== timer =============================================
UCHAR  TMR_1mS_Flags;
UCHAR  TMR_1mS_Count;
UCHAR  TMR_1mS_Cnt;
UCHAR  TMR_10mS_Count;
UCHAR  TMR_10mS_Flags;
UCHAR  TMR_10mS_Cnt;
UCHAR  TMR_100mS_Flags;
UCHAR  TMR_100mS_Cnt;
UCHAR  TMR_1sec_Flags;

#bit TMR_1MS_KEYPAD     = TMR_1mS_Flags.0
#bit TMR_1MS_DELAY      = TMR_1mS_Flags.1

#bit TMR_100mS_BLINK    = TMR_100mS_Flags.0
#bit TMR_100MS_COMM_TO  = TMR_100mS_Flags.1
#bit TMR_100MS_LEDS     = TMR_100mS_Flags.2
#bit TMR_100MS_POWER    = TMR_100mS_Flags.3

#bit TMR_1sec_DISP_STAT =  TMR_1sec_Flags.0
#bit TMR_1sec_RSSI      =  TMR_1sec_Flags.1
#bit TMR_1Sec_TEMP      =  TMR_1sec_Flags.2

//============= I/O PIN assignments ============================

#define PLL_LAT  PIN_C1
#define PLL_CLK  PIN_C2
#define PLL_DAT  PIN_C3
#define PLL_LD   PIN_C0

#define CSN       PIN_B2  // FPGA

#define RS485_EN  PIN_D5

//#define POWER_CTL PIN_D4

#define LED1      PIN_B4
#define LED2      PIN_B5

#define D2A_RESET PIN_B3
#define D2A_CSB   PIN_B1
#define D2A_MOSI  PIN_D4
#define D2A_MISO  PIN_D1
#define D2A_SCLK  PIN_D0

//#define PREAMP_POWER    PIN_
//#define PREAMP_SHUTDOWN PIN_

#define POWER_EN PIN_D6

//========== COM1 variables ====================================
#define COM1_RX_LEN 32

UCHAR COM1_rcnt;
UCHAR COM1_rxi;
UCHAR COM1_rxo;
UCHAR COM1_rbuf[COM1_RX_LEN];

#define COMM_INIT       0
#define COMM_WAIT_DLR   1
#define COMM_WAIT_CR    2
#define COMM_DELAY      3


#define WAIT_ACK_TO 20 // 200mS wait for ack

UCHAR comm_state;
UCHAR comm_ridx;
UCHAR comm_buf[80];
UINT  comm_timeout;

//======= misc =================================================

//----------- setup ----------------------------------------
struct {
       UINT  bitrate;
       UCHAR mode;
       UCHAR clock_polarity;
       UCHAR data_polarity;
       UCHAR clock_source;
       UCHAR data_source;
       UCHAR internal_pattern;
       UCHAR randomizer;
       UCHAR power_high;
       UCHAR SOQPSK;
       UCHAR power_amp;
       UINT  frequency;
       UINT  power_level;
} setup;

UINT allow_write = 0;

const UINT power_in[] = {
  0     ,
  82    ,
  94    ,
  105   ,
  115   ,
  127   ,
  137   ,
  158   ,
  168   ,
  190   ,
  211   ,
  234   ,
  254   ,
  282   ,
  328   ,
  367   ,
  406   ,
  412   ,
  512   ,
  574   ,
  646   ,
  697   ,
  1023
};




//========== function prototypes ===============================
void set_bitrate(UINT bitrate);
void send_FPGA_command(UCHAR length, UCHAR *data);
UCHAR get_FPGA_register(UCHAR addr, UCHAR *data);
UCHAR read_D2A(UCHAR addr);
UCHAR write_D2A(UCHAR addr, UCHAR din);
void read_setup(void);
void write_setup(void);
void update_all(void);

//========== include source files ==============================
#include "AD5312.c"
#include "AD9746.c"
#include "ADF4350.c"
#include "BA1410TX_intr.c"
#include "BA1410TX_serial.c"


//========== functions =========================================

//=============================================================================
//=============================================================================
void send_FPGA_command(UCHAR length, UCHAR *data)
  {
  UCHAR xbyte, cnt;
  output_low(CSN);
  while (length--)
    {
    xbyte = *data++;
    for (cnt = 0; cnt < 8; cnt++, xbyte <<= 1)
      {
      if (xbyte & 0x80)
        output_high(D2A_MOSI);
      else
        output_low(D2A_MOSI);
      delay_us(5);
      output_high(D2A_SCLK);
      delay_us(5);
      output_low(D2A_SCLK);
      delay_us(5);
      }
    }
  output_high(CSN);
  }

//=============================================================================
UCHAR get_FPGA_register(UCHAR addr, UCHAR *data)
  {
  UCHAR xbyte, cnt;
  output_low(CSN);
  for (cnt = 0; cnt < 8; cnt++, addr <<= 1)
    {
    if (addr & 0x80)
      output_high(D2A_MOSI);
    else
      output_low(D2A_MOSI);
    delay_us(5);
    output_high(D2A_SCLK);
    delay_us(5);
    output_low(D2A_SCLK);
    delay_us(5);
    }
  for (xbyte = 0, cnt = 0; cnt < 8; cnt++)
    {
    xbyte <<= 1;
    delay_us(5);
    output_high(D2A_SCLK);
    delay_us(3);
    if (input(D2A_MISO))
      {
      xbyte |= 1;
      delay_us(2);
      }
    delay_us(2);
    output_low(D2A_SCLK);
    delay_us(3);
    }
  *data = xbyte;
  output_high(CSN);
  output_low(D2A_SCLK);
  return xbyte;
  }


//=============================================================================
//BR(31:0)=Round(2^32 * (bit rate)/93.333MHz)
ULONG compute_bitrate_coefficient(ULONG bitrate)
  {
  float bitspersec, temp;
  bitspersec = (float)bitrate;
  temp = bitspersec / 93333000.0;
  temp *= 65536.0;
  temp *= 65536.0;
  return (ULONG)temp - 1;
  }

//=============================================================================
void set_bitrate(UINT bitrate)
  {
  UCHAR buf[7];
  ULONG bitf;
  bitf = compute_bitrate_coefficient((ULONG)bitrate * 10000L);
  buf[0] = 2;
  buf[1] = make8(bitf, 0);
  buf[2] = make8(bitf, 1);
  buf[3] = make8(bitf, 2);
  buf[4] = make8(bitf, 3);
  send_FPGA_command(5, buf);
  }

//=============================================================================
void set_synchronizer_params(void)
  {
  UCHAR buf[7];
  ULONG bitf;
  bitf = compute_bitrate_coefficient((ULONG)setup.bitrate * 10000L);
  buf[0] = 0;
  buf[1] = setup.mode |
           (setup.clock_polarity << 4) |
           (setup.data_polarity  << 5) |
           (setup.randomizer     << 6) |
           (setup.SOQPSK         << 7);
  buf[2] = make8(bitf, 0);
  buf[3] = make8(bitf, 1);
  buf[4] = make8(bitf, 2);
  buf[5] = make8(bitf, 3);
  buf[6] = setup.clock_source |
           (setup.data_source << 1) |
           (setup.internal_pattern << 2);
  send_FPGA_command(7, buf);
  }

//=============================================================================
void write_int_eeprom(UINT addr, UCHAR *data, UINT size)
  {
  while (size--)
    write_eeprom(addr++, *data++);
  }

//=============================================================================
void read_int_eeprom(UINT addr, UCHAR *data, UINT size)
  {
  while (size--)
    *data++ = read_eeprom(addr++);
  }

//=============================================================================
void write_setup(void)
  {
  if (allow_write == 2975)
    write_int_eeprom(0, &setup, sizeof(setup));
  allow_write = 0;
  }

//=============================================================================
void read_setup(void)
  {
  read_int_eeprom(0, &setup, sizeof(setup));
  }

//--------------------------------------------------------------
void power_output(void)
  {
  UINT power;
  if (manual_power != 0xFFFF)
    {
    if (TMR_100MS_POWER)
      {
      TMR_100MS_POWER = 0;
      set_AD5312(1, manual_power);
      }
    return;
    }

  set_adc_channel(5); // select forward power input
  delay_us(20);
  power = read_adc();
  if (power > power_level + 10 || power < power_level - 10)
    {
    if (power > power_level)
      {
      if (power_control >= 150)
        power_control -= 1;
      }
    else if (power_control <= 950)
      {
      power_control += 1;
      }
    set_AD5312(1, power_control);
    }
  }

//=============================================================================
#separate
void delay_mst(UINT delay)
  {
  TMR_1MS_DELAY = 0;
  while (delay)
    {
    if (TMR_1MS_DELAY)
      {
      TMR_1MS_DELAY = 0;
      delay--;
      }
    }
  }


//=============================================================================
void init_io_ports(void)
  {
  output_a(0);
  output_b(0);
  output_c(0);
  output_d(0);
  output_e(0);
  set_tris_a(0b11100001);
  set_tris_b(0b11000001);
  set_tris_c(0b11110001);
  set_tris_d(0b10001110);
  set_tris_e(0b11111001);
  }

//=============================================================================
void init_system(void)
  {

  setup_timer_2(T2_DIV_BY_4,99,10);    // 1.0 ms interrupt

  setup_timer_3(T3_DISABLED | T3_DIV_BY_1);

  setup_timer_4(T4_DIV_BY_4,99,1);     // 100 us interrupt

  setup_timer_5(T5_DISABLED | T5_DIV_BY_1);

  setup_timer_6(T6_DISABLED,0,1);

  init_io_ports();

  setup_adc_ports(sAN0|sAN5);
  setup_adc(ADC_CLOCK_DIV_16|ADC_TAD_MUL_8);

  setup_comparator(NC_NC_NC_NC);

  COM1_init();
  enable_interrupts(INT_TIMER2);
  enable_interrupts(GLOBAL);
  }


//=============================================================================
void update_all(void)
  {
  UINT freq;
  freq = setup.frequency;
  PLL_compute_freq_parameters(freq);
  PLL_update();
  set_synchronizer_params();
  }

//=============================================================================
void main(void)
  {
  int16 vouta = 500;
  init_system();

  read_setup();

  power_level = setup.power_level;
  if (power_level == 0xFFFF)
    power_level = 500;
  power_control = 500;
  power_output();

  PLL_initialize();

  update_all();

  output_high(D2A_RESET);
  delay_ms(1000);
  output_low(D2A_RESET);

  COM1_send_str(VERSION);

  set_AD5312(0, vouta);


  delay_ms(2000);
  output_high(POWER_EN);

#ignore_warnings 203
  while (1)
    {
    if (TMR_100mS_BLINK)
      {
      TMR_100mS_BLINK = 0;
      output_toggle(LED1);
      delay_us(1);
      }
    comm_handler();
    power_output();
    }

}
